document.write("<h3>Idioma: ")
document.write(infoNavegador.idioma);
document.write("</h3>")