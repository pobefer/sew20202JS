document.write("<h2>Nombre: ");
document.write(infoNavegador.nombre);
document.write("</h2>");